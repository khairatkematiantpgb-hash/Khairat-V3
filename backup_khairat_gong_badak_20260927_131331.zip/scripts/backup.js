#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const archiver = require('archiver');

const rootDir = process.cwd();

// Format timestamp: YYYYMMDD_HHmmss
const now = new Date();
const pad = (n) => String(n).padStart(2, '0');
const timestamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;

const zipFileName = `backup_khairat_gong_badak_${timestamp}.zip`;
const zipFilePath = path.join(rootDir, zipFileName);
const latestZipPath = path.join(rootDir, 'khairat_backup_lengkap.zip');

console.log('=====================================================');
console.log(' MEMULAKAN PROSES SANDARAN PENUH APLIKASI (FULL BACKUP)');
console.log(' Pertubuhan Khairat Kematian Gong Badak');
console.log('=====================================================');
console.log(`Masa Sandaran  : ${now.toLocaleString('ms-MY')}`);
console.log(`Nama Fail ZIP  : ${zipFileName}`);
console.log('');

// Files and directories to include
const itemsToInclude = [
  'src',
  'assets',
  'scripts',
  'index.html',
  'vite.config.ts',
  'tsconfig.json',
  'package.json',
  'server.ts',
  'metadata.json',
  '.env.example',
  '.gitignore',
  'db_state.json',
  'PANDUAN_PEMULIHAN.md',
  'backup.sh'
];

// Verify database file exists and count records
if (fs.existsSync(path.join(rootDir, 'db_state.json'))) {
  try {
    const raw = JSON.parse(fs.readFileSync(path.join(rootDir, 'db_state.json'), 'utf8'));
    console.log(`[INFO PANGKALAN DATA]`);
    console.log(` - Ahli Berdaftar : ${raw.members?.length || 0} orang`);
    console.log(` - Rekod Lejar    : ${raw.ledger?.length || 0} rekod`);
    console.log(` - Rekod Kewangan : ${raw.kewangan?.length || 0} rekod`);
    console.log('');
  } catch (e) {
    console.warn('Nota: db_state.json dibaca tetapi ralat format', e.message);
  }
} else {
  console.warn('AMARAN: db_state.json tidak ditemui di folder utama.');
}

const output = fs.createWriteStream(zipFilePath);
const archive = archiver('zip', {
  zlib: { level: 9 } // Maximum compression
});

output.on('close', () => {
  const sizeInMB = (archive.pointer() / (1024 * 1024)).toFixed(2);
  const sizeInKB = (archive.pointer() / 1024).toFixed(1);
  console.log('-----------------------------------------------------');
  console.log(' STATUS: SANDARAN BERJAYA DILENGKAPKAN!');
  console.log(` Saiz Arkib  : ${archive.pointer() >= 1048576 ? `${sizeInMB} MB` : `${sizeInKB} KB`} (${archive.pointer()} bait)`);
  console.log(` Lokasi Fail : ${zipFilePath}`);
  
  // Also create/update a copy with standard name for easy download
  try {
    fs.copyFileSync(zipFilePath, latestZipPath);
    console.log(` Salinan Tetap: ${latestZipPath}`);
  } catch (err) {
    // ignore
  }

  console.log('-----------------------------------------------------');
  console.log('Untuk memulihkan (restore) di komputer baharu:');
  console.log(' 1. Ekstrak fail zip ini ke folder baru.');
  console.log(' 2. Buka terminal dalam folder tersebut dan taip: npm install');
  console.log(' 3. Lancarkan dengan arahan: npm run dev');
  console.log('=====================================================');
});

archive.on('warning', (err) => {
  if (err.code === 'ENOENT') {
    console.warn('Amaran:', err);
  } else {
    throw err;
  }
});

archive.on('error', (err) => {
  console.error('Ralat semasa menghasilkan zip:', err);
  process.exit(1);
});

archive.pipe(output);

// Add items to archive
for (const item of itemsToInclude) {
  const fullPath = path.join(rootDir, item);
  if (!fs.existsSync(fullPath)) continue;

  const stat = fs.statSync(fullPath);
  if (stat.isDirectory()) {
    archive.directory(fullPath, item);
    console.log(` [+] Menambah direktori : ${item}/`);
  } else {
    archive.file(fullPath, { name: item });
    console.log(` [+] Menambah fail      : ${item}`);
  }
}

archive.finalize();
