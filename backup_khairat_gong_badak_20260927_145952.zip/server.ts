import express from 'express';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { createServer as createViteServer } from 'vite';

const PORT = 3000;
const STATE_FILE_PATH = path.join(process.cwd(), 'db_state.json');

// Helper to load state from server file or return null if not present
function loadServerState() {
  try {
    if (fs.existsSync(STATE_FILE_PATH)) {
      const content = fs.readFileSync(STATE_FILE_PATH, 'utf-8');
      return JSON.parse(content);
    }
  } catch (error) {
    console.error('Error loading server state:', error);
  }
  return null;
}

// Helper to normalize the member ID (e.g., '1' -> '001')
function normalizeMemberId(id: any): string {
  if (id === undefined || id === null) return '';
  let base = id.toString().trim();
  if (base.startsWith("'")) base = base.substring(1);
  if (base.endsWith("'")) base = base.substring(0, base.length - 1);
  base = base.trim();
  if (/^\d+$/.test(base)) {
    return base.padStart(3, '0');
  }
  return base;
}

// Helper to sanitize server state payload before saving
function sanitizeServerState(rawState: any) {
  if (!rawState || typeof rawState !== 'object') return rawState;

  const members = Array.isArray(rawState.members)
    ? rawState.members.map((m: any) => ({
        ...m,
        noAhli: normalizeMemberId(m?.noAhli || m?.no || m?.id || ''),
        nama: String(m?.nama || m?.namaAhli || m?.name || '').trim(),
        ic: String(m?.ic || m?.noKadPengenalan || m?.kadPengenalan || m?.noKp || '').trim(),
        alamat: String(m?.alamat || m?.address || '').trim(),
        status: (String(m?.status || m?.statusKeahlian || '').trim().toLowerCase() === 'aktif' || m?.status === 'Aktif') ? 'Aktif' : 'Tidak Aktif',
        tel: String(m?.tel || m?.noTelefon || m?.telefon || m?.phone || '').trim(),
        catatan: String(m?.catatan || m?.nota || m?.remarks || '').trim(),
        tanggungan: Array.isArray(m?.tanggungan)
          ? m.tanggungan.map((t: any) => ({
              nama: String(t?.nama || '').trim(),
              hubungan: String(t?.hubungan || '').trim(),
              ic: String(t?.ic || t?.noKadPengenalan || '').trim()
            })).filter((t: any) => t.nama.length > 0)
          : []
      }))
    : [];

  const ledger = Array.isArray(rawState.ledger)
    ? rawState.ledger.map((l: any) => ({
        ...l,
        noAhli: normalizeMemberId(l?.noAhli || l?.no || l?.id || ''),
        namaAhli: String(l?.namaAhli || l?.nama || '').trim(),
        tahun: Number(l?.tahun) || new Date().getFullYear(),
        jan: l?.jan !== undefined && l?.jan !== null ? String(l.jan).trim() : '',
        feb: l?.feb !== undefined && l?.feb !== null ? String(l.feb).trim() : '',
        mac: l?.mac !== undefined && l?.mac !== null ? String(l.mac).trim() : '',
        apr: l?.apr !== undefined && l?.apr !== null ? String(l.apr).trim() : '',
        mei: l?.mei !== undefined && l?.mei !== null ? String(l.mei).trim() : '',
        jun: l?.jun !== undefined && l?.jun !== null ? String(l.jun).trim() : '',
        jul: l?.jul !== undefined && l?.jul !== null ? String(l.jul).trim() : '',
        ogo: l?.ogo !== undefined && l?.ogo !== null ? String(l.ogo).trim() : '',
        sep: l?.sep !== undefined && l?.sep !== null ? String(l.sep).trim() : '',
        okt: l?.okt !== undefined && l?.okt !== null ? String(l.okt).trim() : '',
        nov: l?.nov !== undefined && l?.nov !== null ? String(l.nov).trim() : '',
        dis: l?.dis !== undefined && l?.dis !== null ? String(l.dis).trim() : '',
        lebihanKredit: Number(l?.lebihanKredit) || 0
      }))
    : [];

  return {
    ...rawState,
    members,
    ledger
  };
}

// Helper to save state to server file
function saveServerState(state: any) {
  try {
    const sanitized = sanitizeServerState(state);
    fs.writeFileSync(STATE_FILE_PATH, JSON.stringify(sanitized, null, 2), 'utf-8');
    return true;
  } catch (error) {
    console.error('Error saving server state:', error);
    return false;
  }
}

async function startServer() {
  const app = express();

  // Support large JSON payloads because the ledger database state can be large
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // API Route: Get State
  app.get('/api/state', (req, res) => {
    const state = loadServerState();
    if (state) {
      res.json({ success: true, state });
    } else {
      res.json({ success: false, message: 'No state file found' });
    }
  });

  // API Route: Save State
  app.post('/api/state', (req, res) => {
    const { state } = req.body;
    if (!state) {
      return res.status(400).json({ success: false, message: 'Missing state payload' });
    }
    const success = saveServerState(state);
    if (success) {
      res.json({ success: true });
    } else {
      res.status(500).json({ success: false, message: 'Failed to save state on server disk' });
    }
  });

  // Proxy Route: Write to Google Apps Script (Bypasses browser CORS, session cookies, and 302 method mutation)
  app.post('/api/apps-script/write', async (req, res) => {
    const { url, payload } = req.body;
    if (!url || !payload) {
      return res.status(400).json({ status: 'error', message: 'URL dan payload diperlukan' });
    }

    try {
      const targetUrl = String(url).trim();
      console.log(`[Proxy Write] Sending action '${payload.action}' to Apps Script:`, targetUrl);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000);

      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        return res.status(response.status).json({
          status: 'error',
          message: `Ralat HTTP dari Apps Script: status ${response.status}`
        });
      }

      const responseText = await response.text();
      let result: any = null;
      try {
        result = JSON.parse(responseText);
      } catch (parseErr) {
        console.warn(`[Proxy Write] Response is not valid JSON. Response starts with:`, responseText.slice(0, 150));
        return res.status(200).json({
          status: 'error',
          message: `Maklum balas daripada Google Apps Script bukan dalam format JSON yang sah (${responseText.slice(0, 80)}...)`
        });
      }
      console.log(`[Proxy Write] Response status:`, result?.status, result?.message);

      // If syncLocalToSheets succeeded, also mirror to local server state db_state.json for high durability
      if (result && result.status === 'success' && payload.action === 'syncLocalToSheets') {
        const currentState = loadServerState() || {};
        const updatedState = {
          ...currentState,
          members: payload.members || currentState.members,
          ledger: payload.ledger || currentState.ledger,
          kewangan: payload.kewangan || currentState.kewangan,
          chartRoles: payload.chartRoles || currentState.chartRoles,
          pekelilingList: payload.pekelilingList || currentState.pekelilingList
        };
        saveServerState(updatedState);
      }

      return res.json(result);
    } catch (err: any) {
      console.error('[Proxy Write] Error writing to Apps Script:', err);
      return res.status(500).json({
        status: 'error',
        message: err.message || 'Gagal menghantar permintaan ke Google Apps Script melalui pelayan'
      });
    }
  });

  // Proxy Route: Fetch from Google Apps Script
  app.get('/api/apps-script/fetch', async (req, res) => {
    const url = req.query.url as string;
    if (!url) {
      return res.status(400).json({ status: 'error', message: 'URL Apps Script diperlukan' });
    }

    try {
      const cleanUrl = url.trim();
      const targetUrl = cleanUrl.includes('action=')
        ? cleanUrl
        : (cleanUrl.includes('?') ? `${cleanUrl}&action=getData` : `${cleanUrl}?action=getData`);

      console.log(`[Proxy Fetch] Fetching from Apps Script:`, targetUrl);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000);

      // 1. Fetch with standard User-Agent header (prevents Google bot challenge)
      let curUrl = targetUrl;
      let finalResponse: any = null;

      // Handle redirect chain manually if needed (Google Apps Script redirects to script.googleusercontent.com)
      for (let redirectCount = 0; redirectCount < 5; redirectCount++) {
        const response = await fetch(curUrl, {
          signal: controller.signal,
          redirect: 'manual',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*'
          }
        });

        if (response.status >= 300 && response.status < 400 && response.headers.get('location')) {
          curUrl = response.headers.get('location')!;
          continue;
        }

        finalResponse = response;
        break;
      }

      clearTimeout(timeoutId);

      if (!finalResponse) {
        throw new Error('Terlalu banyak lencongan (too many redirects) dari Google Apps Script.');
      }

      if (!finalResponse.ok) {
        // Fallback: try POST getData
        try {
          const postRes = await fetch(cleanUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'text/plain;charset=utf-8',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
            },
            body: JSON.stringify({ action: 'getData' })
          });
          if (postRes.ok) {
            const postText = await postRes.text();
            const postData = JSON.parse(postText);
            return res.json(postData);
          }
        } catch {
          // ignore post fallback error
        }

        return res.status(finalResponse.status).json({
          status: 'error',
          message: `Ralat HTTP dari Apps Script: status ${finalResponse.status}`
        });
      }

      const responseText = await finalResponse.text();
      let result: any = null;
      try {
        result = JSON.parse(responseText);
      } catch (parseErr) {
        console.warn(`[Proxy Fetch] Response is not valid JSON. Response starts with:`, responseText.slice(0, 150));
        return res.status(200).json({
          status: 'error',
          message: `Maklum balas daripada Google Apps Script bukan dalam format JSON yang sah.`
        });
      }
      return res.json(result);
    } catch (err: any) {
      console.error('[Proxy Fetch] Error fetching from Apps Script:', err);
      return res.status(500).json({
        status: 'error',
        message: err.message || 'Gagal mengambil data dari Google Apps Script melalui pelayan'
      });
    }
  });

  // API Route: Shorten URL (Ad-free & Direct Redirect)
  app.post('/api/shorten', async (req, res) => {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, message: 'URL diperlukan' });
    }
    
    // 1st Priority: is.gd (100% free, direct redirection, absolutely NO ads or splash screens)
    try {
      console.log('Shortening with is.gd:', url);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const response = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (response.ok) {
        const shortUrl = await response.text();
        if (shortUrl && shortUrl.startsWith('http')) {
          console.log('is.gd produced:', shortUrl);
          return res.json({ success: true, shortUrl });
        }
      }
    } catch (error) {
      console.error('is.gd failed, trying cleanuri:', error);
    }

    // 2nd Priority: cleanuri.com (100% free, no ads, direct redirections)
    try {
      console.log('Shortening with cleanuri.com:', url);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const response = await fetch('https://cleanuri.com/api/v1/shorten', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `url=${encodeURIComponent(url)}`,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (response.ok) {
        const data = await response.json();
        if (data.result_url && data.result_url.startsWith('http')) {
          console.log('cleanuri produced:', data.result_url);
          return res.json({ success: true, shortUrl: data.result_url });
        }
      }
    } catch (error) {
      console.error('cleanuri failed, trying tinyurl:', error);
    }

    // 3rd Priority: tinyurl.com as absolute fallback
    try {
      console.log('Shortening with tinyurl:', url);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      
      const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      
      if (response.ok) {
        const shortUrl = await response.text();
        if (shortUrl && shortUrl.startsWith('http')) {
          console.log('tinyurl produced fallback:', shortUrl);
          return res.json({ success: true, shortUrl });
        }
      }
    } catch (error) {
      console.error('tinyurl also failed:', error);
    }

    res.status(500).json({ success: false, message: 'Gagal memproses pautan pendek secara automatik.' });
  });

  // API Route: Download Full Application Backup ZIP
  app.get('/api/backup/download', (req, res) => {
    try {
      const rootDir = process.cwd();
      const pythonScript = path.join(rootDir, 'scripts', 'backup.py');
      const latestZip = path.join(rootDir, 'khairat_backup_lengkap.zip');
      
      // Execute the backup script to ensure latest state is packed
      if (fs.existsSync(pythonScript)) {
        try {
          execSync(`python3 "${pythonScript}"`, { cwd: rootDir, timeout: 30000 });
        } catch (execErr) {
          console.warn('[Backup] Warning running python3 script:', execErr);
        }
      }
      
      if (!fs.existsSync(latestZip)) {
        return res.status(500).json({ success: false, message: 'Fail sandaran ZIP tidak ditemui' });
      }

      const now = new Date();
      const pad = (n: number) => String(n).padStart(2, '0');
      const timestamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;
      const filename = `backup_khairat_gong_badak_${timestamp}.zip`;

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      const fileStream = fs.createReadStream(latestZip);
      fileStream.pipe(res);
    } catch (err: any) {
      console.error('[Backup Download Error]', err);
      res.status(500).json({ success: false, message: err.message || 'Ralat memuat turun sandaran' });
    }
  });

  // API Route: Backup Info / Status
  app.get('/api/backup/info', (req, res) => {
    try {
      const rootDir = process.cwd();
      const latestZip = path.join(rootDir, 'khairat_backup_lengkap.zip');
      const stateFile = path.join(rootDir, 'db_state.json');

      let zipStats = null;
      if (fs.existsSync(latestZip)) {
        const stats = fs.statSync(latestZip);
        zipStats = {
          size: stats.size,
          sizeFormatted: stats.size > 1048576 ? `${(stats.size / (1024 * 1024)).toFixed(2)} MB` : `${(stats.size / 1024).toFixed(1)} KB`,
          lastModified: stats.mtime
        };
      }

      let memberCount = 0;
      let ledgerCount = 0;
      if (fs.existsSync(stateFile)) {
        const raw = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
        memberCount = raw.members?.length || 0;
        ledgerCount = raw.ledger?.length || 0;
      }

      res.json({
        success: true,
        zipStats,
        database: {
          memberCount,
          ledgerCount
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Vite development middleware vs production static assets
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
